<?php
session_start();

// Ensure this script is accessed via a POST request from our JS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['visitor_name'])) {
    
    $botToken = "[YOUR_TELEGRAM_BOT_TOKEN]"; // <-- REPLACE
    $chatId = "[YOUR_TELEGRAM_CHAT_ID]";     // <-- REPLACE
    
    $visitorName = $_SESSION['visitor_name'];
    $message = "{$visitorName} spanked I2eral succesfully.";

    // Use cURL to send the message
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    $postFields = ['chat_id' => $chatId, 'text' => $message];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    curl_close($ch);

    // Send a success response back to the JS fetch call
    http_response_code(200);
    echo json_encode(['status' => 'success']);
} else {
    // If accessed directly or without a session, deny access
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Forbidden']);
}
?>