<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Device Not Supported - TurboTax</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/img/favicon.ico" type="image/x-icon">
</head>
<body class="page-body">

    <header class="main-header container">
        <img src="img/turbo-logo.svg" alt="Intuit TurboTax Logo" class="header-logo">
        <button class="file-return-btn">File a return</button>
    </header>

    <main class="page-content">
        <div class="content-box incompatible">
            <img src="img/turbo-logo.svg" alt="Warning Icon" class="content-logo">
            <h1>Device Not Supported</h1>
            <p>We're sorry, but this application is designed for and only available on <strong>Windows</strong> desktop devices.</p>
            <p>Please use a Windows computer and revisit this page from your offer email to download the Free TurboTax securely.</p>
        </div>
    </main>

    <footer class="main-footer">
        <div class="container footer-content">
            <div class="footer-left">
                <img src="img/intuit_logo_footer.svg" alt="Intuit" class="intuit-logo">
            </div>
            <div class="footer-center">
                <p>&copy; <?php echo date("Y"); ?> Intuit Inc. All rights reserved.</p>
            </div>
            <div class="footer-right">
                <img src="img/security_trust_seal.svg" alt="TRUSTe Certified Privacy">
                <img src="img/security_efile_certified.svg" alt="E-File Certified">
            </div>
        </div>
    </footer>

</body>
</html>