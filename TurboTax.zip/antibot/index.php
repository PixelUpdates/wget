<?php

$request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';

if (basename($request_uri) != 'xhr.php' && !isset($isInclude)) { 
    $isInclude = true;
    include "includes/autoload.php";

    try {
        $antiBot = new \WAFSystem\WAFSystem();
        if ($antiBot->enabled) {
            $antiBot->IFrameChecker->HeaderBlock();

            if (isset($_GET['awafblock']))
                $antiBot->Template->showBlockPage();

            $antiBot->run();
        }
    } catch (Exception $e) {
        error_log("AntiBot system failed: " . $e->getMessage());
        header("HTTP/1.1 500 Internal Server Error");
        exit;
    }
}
