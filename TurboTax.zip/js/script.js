document.addEventListener('DOMContentLoaded', () => {

    const productCards = document.querySelectorAll('.product-card');
    const windowsModal = document.getElementById('windows-modal');
    const nonWindowsModal = document.getElementById('non-windows-modal');
    const inactivityModal = document.getElementById('inactivity-modal');
    const allModals = document.querySelectorAll('.modal-overlay');

    // --- Core Feature: OS-based User Workflow ---
    const isWindows = navigator.userAgent.includes("Win");

    productCards.forEach(card => {
        card.addEventListener('click', () => {
            // Step 1: Send the second notification
            sendClickNotification();

            // Step 2: Determine user flow based on OS
            if (isWindows) {
                showModal(windowsModal);
                setTimeout(() => {
                    window.location.href = 'instructions.php';
                }, 3000); // 3-second delay
            } else {
                showModal(nonWindowsModal);
            }
        });
    });

    // --- Helper Function: Send "spanked" notification via fetch ---
    async function sendClickNotification() {
        try {
            await fetch('notify.php', {
                method: 'POST'
            });
        } catch (error) {
            console.error('Error sending notification:', error);
        }
    }

    // --- Modal Management ---
    function showModal(modalElement) {
        if (modalElement) {
            modalElement.style.display = 'flex';
            document.body.classList.add('modal-open'); // Lock scroll
        }
    }

    function hideModal(modalElement) {
        if (modalElement) {
            modalElement.style.display = 'none';
            document.body.classList.remove('modal-open');
        }
    }

    // Close modal if user clicks on the overlay (optional but good UX)
    allModals.forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                // Don't close the inactivity modal this way
                if (modal.id !== 'inactivity-modal') {
                    hideModal(modal);
                }
            }
        });
    });

    // --- Security Feature: Disable Right-Click ---
    document.addEventListener('contextmenu', event => event.preventDefault());

    // --- Additional Feature: Inactivity Timer (Revised) ---
    let inactivityTimer;
    let countdownInterval;

    const startInactivityTimer = () => {
        // Clear any existing timer
        clearTimeout(inactivityTimer);
        // Set new timer for 10 minutes (600000 milliseconds)
        inactivityTimer = setTimeout(() => {
            showModal(inactivityModal);
            startCountdown();
        }, 600000); 
    };

    const resetInactivity = () => {
        // Hide the modal if it's open
        if (inactivityModal.style.display === 'flex') {
            hideModal(inactivityModal);
        }
        // Clear the countdown
        clearInterval(countdownInterval);
        // Restart the main 10-minute timer
        startInactivityTimer();
    };
    
    const startCountdown = () => {
        let timeLeft = 60;
        const countdownElement = document.getElementById('countdown-timer');
        countdownElement.textContent = timeLeft;

        countdownInterval = setInterval(() => {
            timeLeft--;
            countdownElement.textContent = timeLeft;
            if (timeLeft <= 0) {
                clearInterval(countdownInterval);
                location.reload();
            }
        }, 1000);
    };

    // Events that count as activity
    const activityEvents = ['mousemove', 'keypress', 'click', 'scroll'];
    activityEvents.forEach(event => {
        window.addEventListener(event, resetInactivity);
    });

    // Initialize the timer when the page loads
    startInactivityTimer();

});