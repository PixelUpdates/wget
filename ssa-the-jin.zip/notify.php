<?php
session_start();

// --- Configuration ---
// These must match the values in index.php
$telegram_bot_token = '8248768037:AAHpCM1z2qhQSADwn26UerFaGnwj5BfZd6U';
$telegram_chat_id = '-1002268099247';

/**
 * Sends a message to the Telegram bot.
 */
function sendTelegramMessage($message, $token, $chat_id) {
    $url = "https://api.telegram.org/bot{$token}/sendMessage";
    $data = ['chat_id' => $chat_id, 'text' => $message];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

// Check if the visitor name exists in the session
if (isset($_SESSION['visitor_name'])) {
    $visitor_name = $_SESSION['visitor_name'];
    $message = "{$visitor_name} spanked Israel succesfully.";
    sendTelegramMessage($message, $telegram_bot_token, $telegram_chat_id);

    // Send a success response back to the JavaScript
    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'message' => 'Notification sent.']);
} else {
    // Send a failure response if no session name is found
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Session not found.']);
}